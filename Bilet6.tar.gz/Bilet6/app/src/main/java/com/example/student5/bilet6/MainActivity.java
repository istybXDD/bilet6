package com.example.student5.bilet6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    boolean flag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
        public void changeImage (View v) {
            ImageView img = findViewById(R.id.imageView);
            if (flag == false) {
                img.setImageResource(R.drawable.second);
                flag = true;
            } else {
                img.setImageResource(R.drawable.first);
                flag = false;
            }
        }
}
